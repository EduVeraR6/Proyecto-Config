﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalesModels
{
    public class Animales
    {
        
        public int Id_animales { get; set; }

        public string? Nombre { get; set; }

        public int? Edad { get; set; }

        public string? Especie { get; set; }

        public string? Genero { get; set; }

        public string? Origen { get; set; }

        public string? Habitat { get; set; }

        public string? Observaciones { get; set; }

        public bool Estado { get; set; }

        public string? Imagen { get; set; }

        public string? Transaccion { get; set; }


    }
}