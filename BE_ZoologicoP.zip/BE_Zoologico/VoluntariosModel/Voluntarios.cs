﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoluntariosModels
{
    public class Voluntarios
    {
        public int? Id_Voluntarios { get; set; }

        public string? Nombres { get; set; }

        public string? Apellidos { get; set; }

        public string? Cedula { get; set; }

        public int? Edad { get; set; }

        public string? Telefono { get; set; }

        public string? Experiencia { get; set; }

        public string? Motivacion { get; set; }

        public string? Imagen { get; set; }

        public bool? Estado { get; set; }

        public string? Transaccion { get; set; }
    }
}
