﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UsuarioModels;
using Backend.Shared;
using System.Data;
using Newtonsoft.Json;
using RespuestaModels;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Configuration;
using Microsoft.AspNetCore.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Xml.Linq;

namespace Backend.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : Controller
    {
        private readonly IConfiguration Configuration;
         public UsuariosController (IConfiguration configuration)
        {   
                Configuration = configuration;
        }

       
        [Route("[action]")]
        [HttpPost]
        public async Task<ActionResult<Usuario>> GetLogin([FromBody] Usuario usuarios)
        {
            try
            {
                var cadenaConexion = new ConfigurationBuilder().AddJsonFile("appsettings.json")
                     .Build()
                     .GetSection("ConnectionStrings")["Conexion"];
                XDocument xmlParam = DBXmlMethods.GetXml(usuarios);

                DataSet resultado = await DBXmlMethods.EjecutaBase(NameStoreProcedure.GET_USUARIOS, cadenaConexion, usuarios.Transaccion, xmlParam.ToString());
                if (resultado.Tables.Count > 0)
                {
                    try
                    {
                        if (resultado.Tables[0].Rows.Count > 0)
                        {
                            Usuario usertem = new Usuario();
                            //usertem.Id = Convert.ToInt32(resultado.Tables[0].Rows[0]["Id"]);
                            usertem.Cedula = resultado.Tables[0].Rows[0]["Cedula"].ToString();
                            return Ok(JsonConvert.SerializeObject(CrearToken(usertem)));
                        }
                        else
                        {
                            RespuestaSP objresponse = new RespuestaSP();
                            objresponse.Leyenda = "Error en las credenciales de acceso";
                            objresponse.Respuesta = "Error";

                        }
                    }
                    catch (Exception e)
                    {
                        Console.Write(e.ToString());
                      
                    }
                }

                return Ok();
            }
            catch (Exception e)
            {
                Console.Write("error" + e.Message);
                return StatusCode(500);
            }
        }

     
        private string CrearToken(Usuario usuario){

            var claims = new List<Claim>{
                new Claim(ClaimTypes.NameIdentifier, usuario.Id.ToString()),
                new Claim(ClaimTypes.Name, usuario.Cedula)
            };

            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(Configuration.GetSection("AppSettings:Token").Value)); 
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddDays(1), //duracion del token
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }



    }
}
