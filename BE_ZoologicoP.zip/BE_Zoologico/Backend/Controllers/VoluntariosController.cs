﻿using VoluntariosModels;
using Backend.Shared;
using Microsoft.AspNetCore.Mvc;
using RespuestaModels;
using System.Data;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VoluntariosController : Controller
    {

        [HttpGet("Voluntarios/{Transaccion}")]

        public async Task<ActionResult<Voluntarios>> GetVoluntarios([FromRoute] string Transaccion)
        {
            Voluntarios voluntario = new Voluntarios();
            voluntario.Transaccion = Transaccion;

            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];

            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
                                                        NameStoreProcedure.GET_VOLUNTARIOS,
                                                        cadenaConexion,
                                                        voluntario.Transaccion,
                                                        null
                                                        );
            List<Voluntarios> listData = new List<Voluntarios>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        Voluntarios objResponse = new Voluntarios
                        {
                            Id_Voluntarios = Convert.ToInt32(row["id_voluntarios"]),
                            Nombres = row["nombres"].ToString(),
                            Apellidos = row["apellidos"].ToString(),
                            Cedula = row["cedula"].ToString(),
                            Edad = Convert.ToInt32(row["edad"]),
                            Telefono = row["telefono"].ToString(),
                            Experiencia = row["experiencia"].ToString(),
                            Motivacion = row["motivacion"].ToString(),
                            Imagen = dsResultado.Tables[0].Columns.Contains("imagen") && row["imagen"] != DBNull.Value
                                ? row["imagen"].ToString() : null
                        };
                        listData.Add(objResponse);
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                }
            }

            return Ok(listData);
        }


        [HttpPost("Voluntarios")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]

        public async Task<ActionResult<RespuestaSP>> PostVoluntarios([FromBody] Voluntarios voluntario)
        {
            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];
            XDocument xmlParam = Shared.DBXmlMethods.GetXml(voluntario);
            DataSet dsResultado = await Shared.DBXmlMethods.EjecutaBase(
                                                    NameStoreProcedure.CRUD_VOLUNTARIOS,
                                                    cadenaConexion,
                                                    voluntario.Transaccion,
                                                    xmlParam.ToString());

            RespuestaSP objRespuesta = new RespuestaSP();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    objRespuesta.Respuesta = dsResultado.Tables[0].Rows[0]["Respuesta"].ToString();
                    objRespuesta.Leyenda = dsResultado.Tables[0].Rows[0]["Leyenda"].ToString();
                }
                catch (Exception e)
                {
                    objRespuesta.Respuesta = "Error";
                    objRespuesta.Leyenda = "Lo sentimos ha ocurrido un error";
                }
            }
            return Ok(objRespuesta);
        }
    }
}
