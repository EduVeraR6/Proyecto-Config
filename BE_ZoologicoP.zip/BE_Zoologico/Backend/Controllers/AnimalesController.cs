﻿using AnimalesModels;
using Backend.Shared;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RespuestaModels;
using System.Data;
using System.Xml.Linq;



namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnimalesController : Controller
    {
        [HttpGet("Animales/{Transaccion}")]

        public async Task<ActionResult<Animales>> GetAnimales([FromRoute] string Transaccion)
        {
            Animales animal = new Animales();
            animal.Transaccion = Transaccion;

            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];

            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
                                                        NameStoreProcedure.GET_ANIMALES,
                                                        cadenaConexion,
                                                        animal.Transaccion,
                                                        null
                                                        );
            List<Animales> listData = new List<Animales>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        Animales objResponse = new Animales
                        {
                            Id_animales = Convert.ToInt32(row["id_animales"]),
                            Edad = Convert.ToInt32(row["edad"]),
                            Especie = row["especie"].ToString(),
                            Nombre = row["nombre"].ToString(),
                            Habitat = row["habitat"].ToString(),
                            Origen = row["origen"].ToString(),
                            Genero = row["genero"].ToString(),
                            Observaciones = row["observaciones"].ToString(),
                            Imagen = row["imagen"].ToString(),
                        };
                        listData.Add(objResponse);
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                }
            }

            return Ok(listData);
        }

        [HttpPost("Animales")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<RespuestaSP>> PostAnimales([FromBody] Animales animal)
        {
            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];
            XDocument xmlParam = Shared.DBXmlMethods.GetXml(animal);
            DataSet dsResultado = await Shared.DBXmlMethods.EjecutaBase(
                                                    NameStoreProcedure.CRUD_ANIMALES,
                                                    cadenaConexion,
                                                    animal.Transaccion,
                                                    xmlParam.ToString());

            RespuestaSP objRespuesta = new RespuestaSP();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    objRespuesta.Respuesta = dsResultado.Tables[0].Rows[0]["Respuesta"].ToString();
                    objRespuesta.Leyenda = dsResultado.Tables[0].Rows[0]["Leyenda"].ToString();
                }
                catch (Exception e)
                {
                    objRespuesta.Respuesta = "Error";
                    objRespuesta.Leyenda = "Lo sentimos ha ocurrido un error";
                }
            }
            return Ok(objRespuesta);
        }
    }
}
