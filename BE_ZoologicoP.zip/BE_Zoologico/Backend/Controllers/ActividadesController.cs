﻿using ActividadModels;
using Backend.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using RespuestaModels;
using System.Data;
using System.Xml.Linq;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ActividadesController : Controller
    {

        [HttpGet("Actividad/{Transaccion}")]
        public async Task<ActionResult<Actividad>> GetActividades([FromRoute] string Transaccion)
        {            
            Actividad actividad     = new Actividad();
            actividad.Transaccion   = Transaccion;

            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];

            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
                                                        NameStoreProcedure.GET_ACTIVIDADES, 
                                                        cadenaConexion,
                                                        actividad.Transaccion,
                                                        null
                                                        );
            List<Actividad> listData = new List<Actividad>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        Actividad objResponse               = new Actividad
                        {
                            ActividadInformacion            = new ActividadInformacion()
                            {
                                Id_ActividadInformacion     = Convert.ToInt32(row["id_actividad"]),
                                Horario                     = new Horario()
                                {
                                    Id_Horario              = Convert.ToInt32(row["id_hora"]),
                                    Hora                    = row["hora"].ToString()
                                },
                                CantidadPersonas            = Convert.ToInt32(row["cantidadPersonas"]),
                                CantidadGuias               = Convert.ToInt32(row["cantidadGuias"]),
                                Precio                      = Convert.ToDecimal(row["precio"]),
                                Descripcion                 = row["descripcion"].ToString()
                            },
                            Nombre                          = row["nombre"].ToString(),
                            Tiempo                          = row["tiempo"].ToString(),
                            Imagen                          = row["imagen"].ToString(),
                        };
                        listData.Add(objResponse);
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                }
            }

            return Ok(listData);
        }


        [HttpGet("Personalizado/{Transaccion}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<Personalizado>> GetPersonalizados([FromRoute] string Transaccion)
        {
            Personalizado personalizado     = new Personalizado();
            personalizado.Transaccion       = Transaccion;

            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];

            DataSet dsResultado = await DBXmlMethods.EjecutaBase(
                                                        NameStoreProcedure.GET_ACTIVIDADES,
                                                        cadenaConexion,
                                                        personalizado.Transaccion,
                                                        null
                                                        );
            List<Personalizado> listData = new List<Personalizado>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        Personalizado objResponse           = new Personalizado
                        {
                            ActividadInformacion            = new ActividadInformacion()
                            {
                                Id_ActividadInformacion     = Convert.ToInt32(row["id_personalizado"]),
                                Horario                     = new Horario()
                                {
                                    Id_Horario              = Convert.ToInt32(row["id_hora"]),
                                    Hora                    = row["hora"].ToString()
                                },
                                CantidadPersonas            = Convert.ToInt32(row["cantidadPersonas"]),
                                CantidadGuias               = Convert.ToInt32(row["cantidadGuias"]),
                                Precio                      = Convert.ToDecimal(row["precio"]),
                                Descripcion                 = row["descripcion"].ToString()
                            },
                            NombreUsuario                   = row["nombreUsuario"].ToString(),
                            Telefono                        = row["telefono"].ToString(),
                            Fecha                           = Convert.ToDateTime(row["fecha"].ToString())
                        };
                        listData.Add(objResponse);
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                }
            }

            return Ok(listData);
        }


        [HttpGet("Horario/{Transaccion}")]
        public async Task<ActionResult<Horario>> GetHorarios([FromRoute] string Transaccion)
        {
            Horario horario       = new Horario();
            horario.Transaccion   = Transaccion;

            var cadenaConexion    = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];

            DataSet dsResultado   = await DBXmlMethods.EjecutaBase(
                                                        NameStoreProcedure.GET_ACTIVIDADES,
                                                        cadenaConexion,
                                                        horario.Transaccion,
                                                        null
                                                        );
            List<Horario> listData = new List<Horario>();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    foreach (DataRow row in dsResultado.Tables[0].Rows)
                    {
                        Horario objResponse = new Horario
                        {
                            Id_Horario  = Convert.ToInt32(row["id_horario"]),
                            Hora        = row["hora"].ToString()
                        };
                        listData.Add(objResponse);
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                }
            }
            return Ok(listData);
        }



        [HttpPost("Actividad")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<RespuestaSP>> PostActividades([FromBody] Actividad actividad)
        {
            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];
            XDocument xmlParam = Shared.DBXmlMethods.GetXml(actividad);
            DataSet dsResultado = await Shared.DBXmlMethods.EjecutaBase(
                                                    NameStoreProcedure.CRUD_ACTIVIDADES, 
                                                    cadenaConexion, 
                                                    actividad.Transaccion, 
                                                    xmlParam.ToString());

            RespuestaSP objRespuesta = new RespuestaSP();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    objRespuesta.Respuesta      = dsResultado.Tables[0].Rows[0]["Respuesta"].ToString();
                    objRespuesta.Leyenda        = dsResultado.Tables[0].Rows[0]["Leyenda"].ToString();
                }
                catch (Exception e)
                {
                    objRespuesta.Respuesta = "Error";
                    objRespuesta.Leyenda = "Lo sentimos ha ocurrido un error";
                }
            }
            return Ok(objRespuesta);
        }


        [HttpPost("Personalizado")]
        public async Task<ActionResult<RespuestaSP>> PostPersonalizado([FromBody] Personalizado personalizado)
        {
            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];
            XDocument xmlParam = Shared.DBXmlMethods.GetXml(personalizado);
            DataSet dsResultado = await Shared.DBXmlMethods.EjecutaBase(
                                                    NameStoreProcedure.CRUD_PERSONALIZADO,
                                                    cadenaConexion,
                                                    personalizado.Transaccion,
                                                    xmlParam.ToString());

            RespuestaSP objRespuesta = new RespuestaSP();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    objRespuesta.Respuesta = dsResultado.Tables[0].Rows[0]["Respuesta"].ToString();
                    objRespuesta.Leyenda = dsResultado.Tables[0].Rows[0]["Leyenda"].ToString();
                }
                catch (Exception e)
                {
                    objRespuesta.Respuesta = "Error";
                    objRespuesta.Leyenda = "Lo sentimos ha ocurrido un error";
                }
            }
            return Ok(objRespuesta);
        }


        [HttpPost("Personalizado/Admin")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<RespuestaSP>> PostAdminPersonalizado([FromBody] Personalizado personalizado)
        {
            var cadenaConexion = new ConfigurationBuilder()
                                    .AddJsonFile("appsettings.json")
                                    .Build()
                                    .GetSection("ConnectionStrings")["Conexion"];
            XDocument xmlParam = Shared.DBXmlMethods.GetXml(personalizado);
            DataSet dsResultado = await Shared.DBXmlMethods.EjecutaBase(
                                                    NameStoreProcedure.CRUD_PERSONALIZADO,
                                                    cadenaConexion,
                                                    personalizado.Transaccion,
                                                    xmlParam.ToString());

            RespuestaSP objRespuesta = new RespuestaSP();

            if (dsResultado.Tables.Count > 0)
            {
                try
                {
                    objRespuesta.Respuesta = dsResultado.Tables[0].Rows[0]["Respuesta"].ToString();
                    objRespuesta.Leyenda = dsResultado.Tables[0].Rows[0]["Leyenda"].ToString();
                }
                catch (Exception e)
                {
                    objRespuesta.Respuesta = "Error";
                    objRespuesta.Leyenda = "Lo sentimos ha ocurrido un error";
                }
            }
            return Ok(objRespuesta);
        }

    }
}
