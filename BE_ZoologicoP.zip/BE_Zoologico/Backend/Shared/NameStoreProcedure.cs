﻿namespace Backend.Shared
{
    public class NameStoreProcedure
    {
        //Actividades
        public const string GET_ACTIVIDADES         = "GET_SP_ACTIVIDADES";
        public const string CRUD_ACTIVIDADES        = "SET_SP_ACTIVIDADES";
        public const string CRUD_PERSONALIZADO      = "SET_SP_PERSONALIZADOS";

        //Animales
        public const string GET_ANIMALES = "GET_SP_ANIMALES";
        public const string CRUD_ANIMALES = "SET_SP_ANIMALES";

        //Voluntarios
        public const string GET_VOLUNTARIOS = "GET_SP_VOLUNTARIOS";
        public const string CRUD_VOLUNTARIOS = "SET_SP_VOLUNTARIOS";


        //Usuarios

        public const string GET_USUARIOS = "GET_SP_USUARIOS";


    }
}
