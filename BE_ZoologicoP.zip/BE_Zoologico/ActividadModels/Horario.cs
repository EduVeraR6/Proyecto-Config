﻿namespace ActividadModels
{
    public class Horario
    {
        public int Id_Horario { get; set; }

        public string? Hora { get; set; }

        public string? Transaccion { get; set; }
    }
}