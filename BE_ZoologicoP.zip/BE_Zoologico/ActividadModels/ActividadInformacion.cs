﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActividadModels
{
    public class ActividadInformacion
    {
        public int Id_ActividadInformacion { get; set; }

        public Horario? Horario { get; set; }

        public int CantidadPersonas { get; set; }

        public int CantidadGuias { get; set; }

        public decimal Precio { get; set; }

        public string? Descripcion { get; set; }
    }
}
