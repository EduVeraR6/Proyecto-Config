﻿namespace RespuestaModels
{
    public class RespuestaSP
    {
        public string? Respuesta { get; set; }
        public string? Leyenda { get; set; }
    }
}